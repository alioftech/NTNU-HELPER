/*
* adc.c
*
* Created: 9/27/2016 3:00:19 PM
*  Author: Ali
*/
#include <avr/io.h>
#include "setup.h" //contains clockspeed used for delays
#include <util/delay.h>
#include "adc.h"
volatile char *ext_adc = (char *) 0x1400; // Start address for the ADC


void adc_init(void)
{
	
	MCUCR |= (1<<SRE);//Enable the external memory interface, same as for SRAM
	SFIOR |= (1<<XMM2);
	
}

int adc_read(int channel)
{
	int adc_value;
	int channel_read = channel+3;
	
	*ext_adc=channel_read; //write
	loop_until_bit_is_clear(PINE, PE0);//wait for ADC_read completed (busy-wait)
	adc_value=ext_adc[channel_read]; //read
	return(adc_value);
	printf("ADC channel %d", channel_read);
	
}
