/*
 * setup.h
 *
 * Created: 04.11.2016 14:03:54
 *  Author: jumaili
 */ 


#ifndef SETUP_H_
#define SETUP_H_

/*
 * setup.h
 *
 * Created: 9/27/2016 2:25:08 PM
 *  Author: Ali
 *	Purpose: Contains the commands needed for delays, and UART
 */ 


//#ifdef SETUP_H_
//#define SETUP_H_

#define F_CPU 4915200UL //The clock speed
#define BAUDRATE 9600
#define MYUBRR F_CPU/16/BAUDRATE-1


#define set_bit( reg, bit ) (reg |= (1 << bit))
#define clear_bit( reg, bit ) (reg &= ~(1 << bit))
#define test_bit( reg, bit ) (reg & (1 << bit))
#define loop_until_bit_is_set( reg, bit ) while( !test_bit( reg, bit ) )
#define loop_until_bit_is_clear( reg, bit ) while( test_bit( reg, bit ) )
#define NULL 0

void enable_interupts();
//#endif



#endif /* SETUP_H_ */