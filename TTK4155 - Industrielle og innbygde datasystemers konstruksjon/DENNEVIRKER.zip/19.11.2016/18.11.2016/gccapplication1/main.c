/*
* Authors:
-Ali Al-Jumaili
-Amund H�ivik
-Erlend H�rstad

* Purpose: To play Ping Pong

* Language:C

* Created: 31.08.2016 11:12:50

//TODO:
-Naming convention for functions and variables, many functions are caps,FIX.


*/

#include "setup.h" //contains clockspeed, UART configurations SHOULD BE INCLUDED BEFORE DELAYS to assure the right delay 
#include <avr/io.h>
#include <util/delay.h> //include delays


#include "oled.h"
#include "uart.h" //UART RS232 Driver
#include "sram.h" //SRAM Driver
#include "joystick.h" //Joystick Driver
#include "menu.h" //Menu Driver
#include "spi.h"
#include "mcp2515.h"
#include "can.h"



int main( void )
{
	/* Test UART */
	uart_init ( MYUBRR );
	printf("Welcome to the terminal...");
	
	//TCCR1A//clear WGM00 and WGM01 mode[0] Normal mode interupt on overflow
	
	/* Test SRAM */
	sram_init();
	sram_test();			//test write, and read to SRAM

	/*Print Welcome screen */
	oled_ini();
	oled_pos(4,7);
	oled_print("Welcome");

	/*Test Joystick */
	printf("Testing Joystick...\n");
	joystick_init();
	
	enable_interupts();		//sets up and enables interrupts.
	
	/* MCP Init */
	mcp2515_init();
	mcp2515_write(MCP_WRITE,5);
	printf("register values: %d", mcp2515_read(MCP_READ));
	

	
	/*	Test CAN	*/
	
	CAN_message_t test;
	if (can_init() == 0) {
		printf("\n\n----CAN working----\n\r");
		test.id = 2;
		test.length = 1;
		test.data[0] = 9;
		} else {
		printf("\n\n----CAN error!!----\n\r");
	}
	
	/*Initialize menu*/
	menu_init();			//sets the menu object to the main menu
	
	while(1)
	{
		if (Joystick_Pos().direction !=  NEUTRAL)
		{
			change_menu(Joystick_Pos().direction);

		}
		printf("Xpos %d \n", Joystick_Pos().x);
		printf("Ypos %d \n", Joystick_Pos().y);
	
	}//while
	
} //main

