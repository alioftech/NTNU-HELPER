/*
 * OLED.h
 *
 * Created: 21.09.2016 12:20:34
 *  Author: erlenhaa
 */ 


#ifndef OLED_H_
#define OLED_H_

#include <stdint.h>

 void write_c(uint8_t cmd);
 void write_d(uint8_t data);
 
 void oled_ini(void);
 void oled_reset(void);
 void oled_home(void);
 void oled_scroll (void);
 void oled_goto_line(int line);
 void oled_goto_column(int column);
 void oled_clear_line(int line); 
 void oled_pos(int column,int line);
 void oled_print(char* c);
 void oled_print_char(char c);



#endif /* OLED_H_ */