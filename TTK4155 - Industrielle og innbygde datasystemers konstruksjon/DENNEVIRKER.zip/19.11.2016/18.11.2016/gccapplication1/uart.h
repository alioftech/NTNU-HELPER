/*
 * UART.h
 *
 * Created: 07.09.2016 09:06:13
 *  Author: amundho
 */ 


#ifndef UART_H_
#define UART_H_

//function prototypes
void uart_init( unsigned int ubrr );
unsigned int uart_transmit(unsigned char data);
unsigned int uart_receive(void);

#endif /* UART_H_ */