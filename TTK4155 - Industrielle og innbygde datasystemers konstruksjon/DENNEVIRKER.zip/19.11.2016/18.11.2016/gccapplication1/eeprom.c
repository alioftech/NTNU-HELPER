/*
 * EEPROM.c
 *
 * Created: 19.11.2016 14:23:58
 *  Author: AtMega162
 */ 
#include "eeprom.h"

unsigned char EEPROM_read(unsigned int uiAddress)
{
	
	while(EECR & (1<<EEWE));											// Wait for completion of previous write 
	EEAR = uiAddress;													// Set up address register 
	EECR |= (1<<EERE);													//Start eeprom read by writing EERE 
	
	return EEDR;
}

void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{

while(EECR & (1<<EEWE));												// Wait for completion of previous write

EEAR = uiAddress;														//Set up address and data registers 
EEDR = ucData;
EECR |= (1<<EEMWE);														// Write logical one to EEMWE 
EECR |= (1<<EEWE);														// Start eeprom write by setting EEWE 
}

void EEPROM_reset()
{
	EEPROM_write(0,0);
	EEPROM_write(1,0);
	EEPROM_write(2,0);
}