/*
 * SRAM.h
 *
 * Created: 14.09.2016 10:49:42
 *  Author: erlenhaa
 */ 


#ifndef SRAM_H_
#define SRAM_H_

void sram_init(void);
void sram_test(void);
#endif /* SRAM_H_ */