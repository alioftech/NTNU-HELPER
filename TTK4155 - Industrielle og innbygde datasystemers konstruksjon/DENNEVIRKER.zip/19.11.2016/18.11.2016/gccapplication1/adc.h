#ifndef ADC_H_
#define ADC_H_


void adc_init(void);
int adc_read(int channel);

#endif