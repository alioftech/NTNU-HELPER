/*
 * game.c
 *
 * Created: 09.11.2016 08:57:21
 *  Author: jumaili
 */ 

#include "game.h"
#include "can.h"
#include "oled.h"
#include "menu.h"
#include "joystick.h"

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint-gcc.h>
#include <util/delay.h>

int game_ongoing; //0: game over, 1: game ongoing
int score;
uint32_t counter;
int timer_flag;

void game_start_new()
{
	score = 0;							//reset gamescore
	game_ongoing = 1;					//game is ongoing
	timer_flag = 0;
	
	CAN_message_t game_over_msg;		  //for recieving game over msg
	
	game_draw_screen();
	game_start_msg();					//send start msg to arduino
	//TODO: make/start timer, Timer interrupt should set timer_flag = 1 and nothing more, rest of code is done
	init_timer();
	while(game_ongoing == 1)					// waiting for game over message
	{
		joystick_send();						//sending joypos and button with Can
		game_update_score();	
		game_over_msg = can_data_receive();		//wait for game over msg
		if(game_over_msg.id == 80)			
		{			
			game_ongoing = 0;	//game over 
	
		}	
	}
	game_over();
}


void game_draw_screen()
{	
		oled_reset(); //reset screen
		oled_pos(1,7);
		oled_print("Score");
		oled_pos(3,0);
		oled_print("--------------------");
		oled_pos(4,9);
		print_score(score);
		oled_pos(5,0);
		oled_print("--------------------");
}

void game_update_score()
{
	if(timer_flag == 1)			//Triggered by interrupt
	{
		score += 1;			//add a point
		game_draw_screen();		//update screen
		timer_flag = 0;			//reset flag
	}
}

void game_over()
{
	//Game over screen
	oled_reset(); //reset screen
	oled_pos(3,6);
	oled_print("Game Over");
	oled_pos(5,8);
	print_score(score);
	_delay_ms(2000);
	for (int i = 0; i<3; i++) //blink screen n times
	{	
		oled_reset(); //reset screen
		_delay_ms(2000);
		oled_pos(3,6);
		oled_print("Game Over");
		oled_pos(5,8);
		print_score(score);
		_delay_ms(2000);
	}
	_delay_ms(2000);
	
	if(score >= thirdPlace.numChildren) // check if score should go to highscore list
	{
		if (score >= EEPROM_read(first)) //first place
		{
			EEPROM_write(third,EEPROM_read(second));
			EEPROM_write(second,EEPROM_read(first));
			EEPROM_write(first,score);
		}
		else if (score >= EEPROM_read(second) ) //second place
		{
			EEPROM_write(third,EEPROM_read(second));
			EEPROM_write(second,score);
		}
		else if (score >= EEPROM_read(third)) //third place
		{
			EEPROM_write(third,score);
		}
	}
	 	
}
void game_start_msg()
{
		CAN_message_t message;
		
		//Give message ID and length
		message.id = 90;		//90 for start game msg;
		message.length = 1;

		message.data[0] = difficulty.child_selected;
		
		//send message
		can_message_send(&message);
}
char* print_score(int s)
{		
		char c[8];
		itoa(s, c, 10);
		oled_print(c);
}

void init_timer()
{
	OCR1A   = 19200; // Set CTC compare value to 1Hz at 1.6MHz AVR clock, with a prescaler of 256
	TCCR1B |= (1 << WGM12); // Configure timer 1 for CTC mode
	TCCR1B |= (1 << CS12); //set prescaler to 256
	TIMSK |= (1 << OCIE1A); // Enable CTC interrupt
}

ISR(TIMER1_COMPA_vect)
{	
	if (game_ongoing)
	{
		timer_flag = 1;
	}
	else{}
		//Ignore interrupt
}