/*
 * menu.h
 *
 * Created: 05.10.2016 08:47:30
 *  Author: erlenhaa
 */ 

#include <string.h>

#ifndef MENU_H_
#define MENU_H_

#include "joystick.h"



typedef struct screen screen;
screen main_menu, new_game, highscore, calibration, firstPlace, secondPlace, thirdPlace, difficulty, hard, normal, easy, reset;

struct screen {
	char *name;
	struct screen *parent;
	int numChildren,child_selected;
	struct screen **child; //same as child[] he said
};

//struct screen * init_menu(void);
void draw_screen(screen* menu);
void menu_init();
void change_menu(direction_t);


#endif /* MENU_H_ */