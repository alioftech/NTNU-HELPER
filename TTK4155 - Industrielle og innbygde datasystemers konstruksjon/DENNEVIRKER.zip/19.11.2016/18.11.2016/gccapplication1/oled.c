/*
* OLED.c
*
* Created: 21.09.2016 12:20:18
*  Author: erlenhaa
*/

#include "OLED.h"
#include "font 8x8.h"
#include "joystick.h"
#include <avr/io.h>


#define FONTWIDTH 6
volatile char *oled_cmd = (char *) 0x1000; // Start address for the OLED_Command
volatile char *oled_data = (char *) 0x1200; // Start address for the OLED_DATA

int page,col;

void write_c(uint8_t cmd)
{
	*oled_cmd = cmd;
}


void write_d(uint8_t data)
{
	*oled_data = data;
}

void oled_ini(void)
{
	
	//Enable the external memory interface
	MCUCR |= (1<<SRE);
	SFIOR |= (1<<XMM2);

	write_c(0xae);        //  display  off
	write_c(0xa1);        //segment  remap
	write_c(0xda);        //common  pads  hardware:  alternative
	write_c(0x12);
	write_c(0xc8);        //commonoutput scan direction:com63~com0
	write_c(0xa8);        //multiplex  ration  mode:63
	write_c(0x3f);
	write_c(0xd5);        //displayc divide ratio/osc. freq. mode
	write_c(0x80);
	write_c(0x81);        //contrast  control
	write_c(0x50);
	write_c(0xd9);        //set  pre-charge  period
	write_c(0x21);
	write_c(0x20);        //Set  Memory  Addressing  Mode
	write_c(0x00);
	write_c(0xdb);        //VCOM  deselect  level  mode
	write_c(0x30);
	write_c(0xad);        //master  configuration
	write_c(0x00);
	write_c(0xa4);        //out  follows  RAM  content
	write_c(0xa6);        //set  normal  display
	write_c(0xaf);        //  display  on
	
	oled_reset();
	oled_home();
	
	
	
	
}



void oled_home(void) {
	//Give start value for page and colum
	page = 0;
	col = 0;

	//Set the cursor to orgin
	*oled_cmd = 0x21; //colum start
	*oled_cmd = 0x00;
	*oled_cmd = 0x7f; //Set Display Start Line

	*oled_cmd = 0x22; //page start
	*oled_cmd = 0x00;
	*oled_cmd = 0x7;//Set Display Start Line
}
/*
void oled_scroll (void){
		
		if (Joystick_Pos().direction == DOWN){
		
				}
	
		if (Joystick_Pos().direction == NEUTRAL){
			*oled_cmd = 0x2E; // deavctivate scrolling
		}
	
}
oled_mainmenu_t
{
  const char *name; // name to be rendered
  functionPointer handlerFunc; // handler for this leaf node (optionally NULL)
  struct menu *child; // pointer to child submenu (optionally NULL)
};

struct oled_submenu
{
  struct menu *parent; // pointer to parent menu
  struct **menuitem; // array of menu items, NULL terminated
};
*/
void oled_goto_line(int line)
{
	oled_home();

	//Check if it's a valid page
	if (line < 8)  //extra safety
	{
		page = line; 						//temp vari saves the lines

		*oled_cmd = 0x00; 			//Set lower column address

		*oled_cmd = 0x10;					//Set higher column address

		*oled_cmd = 0xB0 | line; 		//Set page address depending on the line
	}

}

void oled_pos(int line, int column)
{
	oled_goto_line(line);


	if (column < (128/FONTWIDTH))  //determinant by the font
	{
		//Save the column we are moving to
		col = column*FONTWIDTH;
		//Set lower column start address
		*oled_cmd = 0x00 + (column*(FONTWIDTH)>>4);
		//Set higher column start address
		*oled_cmd = 0x10 + (column*(FONTWIDTH)>>4);
	}


}

void oled_clear_line(int line)
{
	oled_goto_line(line);

	//Clear the page
	for (int i = 0; i < 128; i++) {
		*oled_data=0x00;
	}

	oled_home();

}

void oled_reset(void)
{
	//Clear every page
	for (int k = 0; k < 8; k++)
	oled_clear_line(k);

}

void oled_print_char(char c)
{
	//Write the complete character
	for (int i = 0; i < FONTWIDTH; i++) 
	{
		*oled_data = pgm_read_byte(&font[c-' '][i]); //TODO:change the name of this varible
	}
	


}

void oled_print(char *buffer)
{
	int i = 0;

	//Write the complete string
	while(buffer[i] != '\0') //until buffer is finished '\0' --> NUL
	{
		oled_print_char(buffer[i]);
		i++;
	}
	return 0;
}



