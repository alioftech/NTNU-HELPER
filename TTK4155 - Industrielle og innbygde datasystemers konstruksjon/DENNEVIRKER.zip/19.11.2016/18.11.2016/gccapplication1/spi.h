/*
 * spi.h
 *
 * Created: 12.10.2016 10:46:15
 *  Author: erlenhaa
 */ 


#ifndef SPI_H_
#define SPI_H_

//Define SPI pins
#define SPI_CS PB4
#define SPI_MOSI PB5
#define SPI_MISO PB6
#define SPI_SCK PB7


int SPI_init(void);
int SPI_send(char data);
int SPI_read(void);

void SPI_select(void); //enable chip select
void SPI_deselect(void);



#endif /* SPI_H_ */

