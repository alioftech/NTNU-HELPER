/*
 * Joystick.h
 *
 * Created: 14.09.2016 14:54:10
 *  Author: erlenhaa
 */ 


#ifndef JOYSTICK_H_
#define JOYSTICK_H_

typedef enum {LEFT, RIGHT, UP, DOWN, NEUTRAL} direction_t;

typedef struct percentXY {
	int x, y;
	direction_t direction; //string
	
}percentXY_t;

void joystick_init(void);
struct percentXY Joystick_Pos(void);

int isButtonPressed(void);
void Joystick_calibration(void); 
void joystick_send(void);
int slider_pos(char rl);
#endif /* JOYSTICK_H_ */