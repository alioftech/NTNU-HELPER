#include <avr/io.h>
#include "spi.h"


/**
 * \brief 
 * 
 * \param 
 * 
 * \return int
 */
int SPI_init(void) {
	//Set MOSI, SCK and CS as output pins
	DDRB |= (1<<SPI_MOSI) | (1<<SPI_SCK) | (1<<SPI_CS);
	
	//Set MISO as input pin
	DDRB &= ~(1<<SPI_MISO);
	
	//Enable SPI in master mode and set clock rate fosc/16
	SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0);
	
	return 0;
}

/**
 * \brief 
 * 
 * \param data
 * 
 * \return int
 */
int SPI_send(char data) {
	//Start the transmission
	SPDR = data;
	
	//Wait for data to be transmitted (checks if the register is empty)
	while(!(SPSR & (1<<SPIF)));
	
	return 0;
}

/**
 * \brief 
 * 
 * \param 
 * 
 * \return int
 */
int SPI_read(void) {
	//Send dummy data to read from slave
	SPI_send(0);
	
	//Wait for data to be received
	while(!(SPSR & (1<<SPIF)));
	
	return SPDR;
}

/**
 * \brief 
 * 
 * \param 
 * 
 * \return void
 */
void SPI_select(void)
{
	
	PORTB &= ~(1<<SPI_CS);//Set !CS to 0 to select the slave
}

/**
 * \brief 
 * 
 * \param 
 * 
 * \return void
 */
void SPI_deselect(void) {
	
	PORTB |= (1<<SPI_CS);//Set !CS to 1 to deselect the slave
}