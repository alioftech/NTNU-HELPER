/*
 * eeprom.h
 *
 * Created: 19.11.2016 14:24:25
 *  Author: AtMega162
 */ 


#ifndef EEPROM_H_
#define EEPROM_H_

#include <avr/io.h>

unsigned char EEPROM_read(unsigned int);
void EEPROM_write(unsigned int uiAddress, unsigned char ucData);

void EEPROM_reset(void);

#endif /* EEPROM_H_ */