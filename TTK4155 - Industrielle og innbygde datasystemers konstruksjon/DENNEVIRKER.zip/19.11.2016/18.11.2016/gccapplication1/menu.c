/*
* menu.c
*
* Created: 05.10.2016 08:45:50
*  Author: erlenhaa
*/
#include "setup.h"
#include "menu.h"
#include "oled.h"
#include "joystick.h"
#include "game.h"
#include <stdlib.h>
#include <string.h>
#include <util/delay.h>


const char* menuNames[5] = {"Main Menu", "New Game", "Highscores",  "JS Calibration", "Clear highscore"};

char mainMenuName[] = "Main Menu";
char newGameName[] = "New Game";
char HighscoreName[] = "Highscores";
char JSCalName[] = "JS Calibration";
char FirstPlace[] = "5";
char SecondPlace[] = "3";
char ThirdPlace[] = "1";
char Difficulty[] = "Set Difficulty";
char Hard[] = "Hard";
char Normal[] = "Normal";
char Easy [] = "Easy";
char Reset[]  = "Reset Highscore";

//screen main_menu, new_game, highscore, calibration, firstPlace, secondPlace, thirdPlace, difficulty, hard, normal, easy;
screen *menu;

screen* mainMenuChildren[] = {&new_game, &highscore, &difficulty, &calibration};
screen* highscoreChildren[] = {&firstPlace, &secondPlace, &thirdPlace};
screen* newGameChildren[] = {};
screen* calibrationChildren[] = {};
screen* resetChildren[] = {};
screen* difficultyChildrem[] = {&easy, &normal, &hard};

screen main_menu = {
	.name = mainMenuName,
	.parent=NULL,
	.child = mainMenuChildren,
	.numChildren = sizeof(mainMenuChildren)/sizeof(screen*),
	.child_selected=0,
};
screen highscore = {
	.name = HighscoreName,
	.parent = &main_menu,
	.child = highscoreChildren,
	.numChildren = sizeof(highscoreChildren)/sizeof(screen*),
	.child_selected=0,
};
screen new_game = {
	.name = newGameName,
	.parent = &main_menu,
	.child = newGameChildren,
	.numChildren = sizeof(newGameChildren)/sizeof(screen*),
	.child_selected=0,
};
screen calibration = {
	.name = JSCalName,
	.parent = &main_menu,
	.child = calibrationChildren,
	.numChildren = sizeof(calibrationChildren)/sizeof(screen*),
	.child_selected=0,
};

screen difficulty = {
	.name = Difficulty,
	.parent = &main_menu,
	.child = difficultyChildrem,
	.numChildren = sizeof(difficultyChildrem)/sizeof(screen*),
	.child_selected=0,
};
screen reset = {
	.name = Reset,
	.parent = &main_menu,
	.child = resetChildren,
	.numChildren = sizeof(resetChildren)/sizeof(screen*),
	.child_selected=0,
};
screen hard = {
	.name = Hard,
	.parent = &difficulty,
	.child = NULL,
	.numChildren = NULL,
	.child_selected=NULL,
};
screen normal = {
	.name = Normal,
	.parent = &difficulty,
	.child = NULL,
	.numChildren = NULL,
	.child_selected=NULL,
};
screen easy = {
	.name = Easy,
	.parent = &difficulty,
	.child = NULL,
	.numChildren = NULL,
	.child_selected=NULL,
};

screen firstPlace = {
	.name = FirstPlace,
	.parent = &highscore,
	.child = NULL,
	.numChildren = 5,
	.child_selected=0,
};
screen secondPlace = {
	.name = SecondPlace,
	.parent = &highscore,
	.child = NULL,
	.numChildren = 3,
	.child_selected=0,
};
screen thirdPlace = {
	.name = ThirdPlace,
	.parent = &highscore,
	.child = NULL,
	.numChildren = 1,
	.child_selected=0,
};

void menu_init()
{
	menu = &main_menu;
	draw_screen(menu);
}



void draw_screen(screen* menu)		//screen myScreen = main_menu;
{
	//clear screen
	oled_reset();
	//print header
	oled_print(menu->name);
	oled_goto_line(1);
	oled_print("--------------------");
	
	//print children or score
	
	if (menu == &highscore)
	{
		oled_pos(2,0);
		oled_print("First");
		oled_pos(2,8);
		print_score(EEPROM_read(0));
		
		oled_pos(4,0);
		oled_print("Second");
		oled_pos(4,8);
		print_score(EEPROM_read(1));
		
		oled_pos(6,0);
		oled_print("Third");
		oled_pos(6,8);
		print_score(EEPROM_read(2));
	}

	else
	{
		int index=menu->child_selected+2; //2 cuz of the 2 first lines
		oled_pos(index,0);//draw the arrow using the position of the counter
		oled_print("->"); //arrow for now
		for (int i = 0; i < menu->numChildren; i++)
		{
			oled_pos(2+i, 3);
			oled_print(menu->child[i]->name);
		}
	}

} //draw_screen


void change_menu(direction_t dir)
{
	if (menu != &highscore) //Disables Up, Down and Right when wieving high scores
	{	
		if (dir==DOWN)
		{
			if(menu->child_selected < menu->numChildren)
			menu->child_selected++; //increase menu number
			
			if(menu->child_selected>menu->numChildren-1) //start at the top again
			menu->child_selected=0; //reset
			
			draw_screen(menu);
		}
		
		
		if (dir == UP)
		{
			if (menu->child_selected > 0)
			menu->child_selected--; //decrement
			
			if (menu->child_selected<0) //start at the bottom of the page
			menu->child_selected=menu->numChildren-1; //if arrow has reached the highest selection (lowest value)
			
			draw_screen(menu);
		}
		
		if (dir == RIGHT)
		{
			if (menu == &difficulty)
			{
				
				menu = menu->parent;				//Go back to main menu
			}
			else if (menu->child[menu->child_selected] != NULL)
			{
				menu = menu->child[menu->child_selected];	
			}
		
			if (menu == &calibration)				//Check if menu is Calibration
			{
				Joystick_calibration();
				menu = menu->parent;
			}
			
			if (menu == &new_game)
			{
				game_start_new();
				menu = &highscore; //when game is over
			}
			//if (menu == &reset)
			//{
				//EEPROM_reset();
				//oled_reset();
				//oled_pos(4,2);
				//oled_print("Highscore is reset");
				//_delay_ms(1000);
				//menu = &main_menu; //when game is over
			//}

			draw_screen(menu);
		}

	}//Disable UP DOWN AND RIGHT
	
	if (dir == LEFT)
	{
		if (menu->parent != NULL)
		{
			menu = menu->parent;
			draw_screen(menu);
		}
		
	}
	while(Joystick_Pos().direction != NEUTRAL);
}