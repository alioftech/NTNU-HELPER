/*
 * setup.c
 *
 * Created: 04.11.2016 13:56:07
 *  Author: jumaili
 */ 
#include "setup.h"
#include <avr/io.h>
#include <avr/interrupt.h> //include interupts

void enable_interupts()
{
		cli();
		/*-----Interrupts-----*/
		
		//CAN INT
		DDRD &= ~(1<<PD2);			//input PD2
		GICR |= (1 << INT0);		//Enable INT0
		MCUCR |= (1<<ISC01);		//Trigger on falling edge
		MCUCR &= ~(1<<ISC00);		//Trigger on falling edge
		
		
		//BUTTON INT1
		DDRD &= ~(1<<PD3);			//input PD3
		GICR |= (1 << INT1);		//Enable INT1
		MCUCR |= (1<<ISC11);		//Trigger on falling edge
		MCUCR &= ~(1<<ISC10);		//Trigger on falling edge
		
		//BUTTON INT2
		//DDRE &= ~(1<<PE0);	//input PE0
		//GICR |= (1 << INT2);		//Enable INT2
		//EMCUCR &= ~(1<<ISC2);		//Trigger on falling edge
		
		sei(); //enable i-bit
}

