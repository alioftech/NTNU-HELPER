/*
* can.h
*
* Created: 12.10.2016 14:55:55
*  Author: erlenhaa
*/


#ifndef CAN_H_
#define CAN_H_
#include <stdint-gcc.h>

uint8_t rx_flag;

typedef struct {
	int id;
	uint8_t length;
	int8_t data[8];
} CAN_message_t;

int can_init(void);
int can_message_send(CAN_message_t* message);
int can_error(void);
int can_transmit_complete(void);
CAN_message_t can_data_receive(void);



#endif /* CAN_H_ */