/*
 * game.h
 *
 * Created: 09.11.2016 08:57:31
 *  Author: jumaili
 */ 


#ifndef GAME_H_
#define GAME_H_

#define first 0
#define second 1
#define third 2

void game_start_new(void);
void game_draw_screen(void);
void game_update_score(void);
void game_over(void);
void game_start_msg(void);
char* print_score(int);
void init_timer(void);


#endif /* GAME_H_ */