/*
* Joystick.c
*
* Created: 14.09.2016 14:53:58
*  Author: erlenhaa
*/
#include "setup.h"
#include <util/delay.h>
#include <stdlib.h>
#include <stdint-gcc.h>
#include "Joystick.h"
#include "adc.h"
#include "oled.h"
#include "can.h"
#include "menu.h"
#include <avr/io.h>
#include <avr/interrupt.h>
int zeroPosX=128;
int zeroPosY=128;

int maxXpos, minXpos, maxYpos, minYpos, xOffset, yOffset;
int buttonIsPressed;

void joystick_init(void)
{
	
	//setup for button
	buttonIsPressed = 0;
		
	//Standard values for calibration
	maxXpos = 255;
	maxYpos = 255;
	minYpos = 0;
	minXpos = 0;
	zeroPosX = 128;
	zeroPosY = 128;
	xOffset = 0;
	yOffset = 0;
	
	//auto calibrate on startup
	percentXY_t startPos = Joystick_Pos();
	xOffset = 50-startPos.x;
	yOffset = 50-startPos.y;	
}

percentXY_t Joystick_Pos(void)
{
	
	int xPos, yPos; //local varibles
	percentXY_t position; //struct type
	
	//Read ADC channels
	xPos=adc_read(1); //read channel 1 on ADC (x-axis)
	yPos=adc_read(2); //read channel 2 on ADC (y-axis)
	

	//Converting ADC from 0 to 100 %
	position.y= 100*(yPos)/0xFF + yOffset; //Convert to precentage and adjust offset
	position.x = 100*(xPos)/0xFF + xOffset; //Convert to precentage and adjust offset
	
	
	//set direction
	if(position.y>55)
	{
		position.direction=UP;
		//printf("Up");
	}
		
	else if (position.y<45)
	{
		position.direction=DOWN;
		//printf("Down\n");
	}
	
	if (position.x>55)
	{
		position.direction=RIGHT;
	//	printf("RIght \n");
	}
	
	else if(position.x<45)
	{
		position.direction=LEFT;
		//printf("Left"\n);
	}
	
	else if(position.x>=45 && position.x<=55 && position.y>=45 &&position.y<=55){
		position.direction=NEUTRAL;
		//printf("neutral\n");
	}
	
	
	return position; //return the struct
}


//int isButtonPressed(void)
//{
	//if(!(test_bit(PINB,PINB0)))
	//{
		//printf("button/n");
		//return 1;
	//}
	//else 
	//return 0;
//}
void Joystick_calibration(void) 
{
		//Reset calibration values
		maxXpos = 0;
		maxYpos = 0;
		minYpos = 0;
		minXpos = 0;
		zeroPosX = 128;
		zeroPosY = 128;
		
	
		//LEFT 
		oled_reset();
		oled_pos(4,2);
		oled_print("MOVE LEFT AND HOLD");
		while (adc_read(1) > 20); //wait for user to move joystick
		_delay_ms(500);
		minXpos = adc_read(1);
	
		
		//Right 
		oled_reset();
		oled_pos(4,2);
		oled_print("MOVE RIGHT AND HOLD");
		while (adc_read(1) < 235 ); //wait for user to move joystick
		_delay_ms(500);
		maxXpos = adc_read(1);

		
		//UP 
		oled_reset();
		oled_pos(4,3);
		oled_print("MOVE UP AND HOLD");
		while (adc_read(2) < 235 ); //wait for user to move joystick
		_delay_ms(500);
		maxYpos = adc_read(2);

		
		//DOWN 
		oled_reset();
		oled_pos(4,2);
		oled_print("MOVE DOWN AND HOLD");
		while (adc_read(2) > 20 ); //wait for user to move joystick
		_delay_ms(500);
		minYpos = adc_read(2);
	
		//DONE
		oled_reset();
		oled_pos(4,3);
		oled_print("CALIBRATION DONE!");
		_delay_ms(1000);
	
}
void joystick_send(void)
{
	
	CAN_message_t message;			//Create CAN message
	
									//Give message ID and length 
	message.id = 110;				//110 for joy pos msg;
	message.length = 4;
	
	//Collect joystick pos and put into data field of the message
	percentXY_t posision = Joystick_Pos();
	int slider = slider_pos('r');
	
	message.data[0] = posision.x;
	message.data[1] = posision.y;
	message.data[3] = slider;

	if (buttonIsPressed == 1)
	{
		message.data[2] = 1;
		buttonIsPressed = 0;
		printf("Button\n");
	}
	else if(buttonIsPressed == 0)
	{
		message.data[2] = 0;
	}
	
	can_message_send(&message);
	while (!(can_transmit_complete()));
	
}

int slider_pos(char rl)
{
	int val = 0;
	int pos = 0;
	if (rl == 'r')
	{
		val=adc_read(4);///0xFF*100; //right
		pos = 100*(val)/255;
		return pos;
	}
	else if (rl == 'l')
	{
		val=adc_read(3);///0xFF*100; //right
		pos = 100*(val)/255;
		return pos;
	}
	
	else
	{
		return -1;
		printf("slider error");
	}
}

ISR(INT1_vect) {
	buttonIsPressed = 1;
}