/*
 * game.c
 *
 * Created: 17.11.2016 18:41:58
 *  Author: erlenhaa
 */ 

#include "game.h"
#include "can.h"
#include "pwm.h"
#include "solenoid.h"
#include "motor.h"
#include "pid.h"
#include "uart.h"
#include "ir_sensor.h"
#include <stdio.h>

void play_game(void)
{
	int16_t sliderPos = 0;
	int16_t shoot = 0;
	int16_t xPos = 0;
	int16_t yPos = 0;
	int16_t difficulty = 1;								//default normal
	CAN_message_t msg;
	
	while(1)
	{
						
		msg = can_data_receive();
		if (msg.id != -1) 
		{
			xPos = msg.data[0];							//read Can msg information
			yPos = msg.data[1];
			shoot = msg.data[2];
			sliderPos = msg.data[3];
			
			servo_control((float)xPos);					//control servo
			pi_update_pos(sliderPos);						//Update ref_posisio
			pi_controller();							//Update difficulty
			
			if (shoot == 1)								//Activate solinoid
			{
				printf("Button\n");
				enable_solenoid();
			}			
		}
		if (ir_obstructed())							//send game over msg when ir_sensor is obstructed
		{
			CAN_message_t msg;
			msg.id = 80;
			msg.length = 0;
			can_message_send(&msg);
			
			//Drive motor to center
			int16_t center = encoder_MAX/2;
			int16_t value = read_encoder();
			
			if (value > center)
			{
				motor_direction('r');
				motor_speed(90);			
				while(1)
				{
					int16_t read = read_encoder();
					if (read < center)
					{
						break;
					}
				}
			}
			else
			{
				motor_direction('l');
				motor_speed(90);	
				while(1)
				{
					int16_t read = read_encoder();
					if (read > center)
					{
						break;
					}
				}
			}
			motor_speed(0);
			servo_control(50);
			break;
		} //If obstructed			
	}//while
		
}