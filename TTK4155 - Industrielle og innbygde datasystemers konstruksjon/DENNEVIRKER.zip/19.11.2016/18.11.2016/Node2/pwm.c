/*
* pwm.c
*
* Created: 31.10.2016 18:09:02
*  Author: jumaili
*/
#include <avr/io.h>
#include "pwm.h"

void pwm_init()//choosing 16-bit timer on OC3A
{
	//choose mode mode 14 (FAST PWM) table 16-8
	TCCR3A  |=  (1 << WGM31);
	TCCR3B  |=  (1 << WGM32) | (1 << WGM33);
	
	//Clear on compare match, set at BOTTOM (table 17-4) 
	TCCR3A  |=  (1 << COM3A1);
	
	// 1/64 prescaler
	TCCR3B  |=  (1 << CS31)	| (1 << CS30);
	
	// Set TOP value
	ICR3 = FCPU/64/1000*20;
	
	//make PE3 output for PWM
	DDRE|=(1<<PINE3);
	
	servo_control(50);							
	
}
void pwm_width(float poswidth_ms){
	OCR3A = FCPU/64/1000 * poswidth_ms;
}
void servo_control(int xpos){
	int xInv = -xpos + 100;											//Invers servo
	float min_pwm = 0.9;
	float max_pwm = 2.1;
	float pwm_return = min_pwm + (max_pwm-min_pwm)*(float)xInv/100; //offset on pingpong (should have been 100)
	pwm_width(pwm_return);
}