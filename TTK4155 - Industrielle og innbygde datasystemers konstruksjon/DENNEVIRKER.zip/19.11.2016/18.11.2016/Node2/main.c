/*
* main.c
*
* Created: 26.10.2016 11:29:27
*  Author: erlenhaa
*/
#include "setup.h" //contains clockspeed, UART configurations
#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h> //include delays
#include <avr/interrupt.h> //include interrupts

#include "uart.h" //UART RS232 Driver
#include "spi.h"
#include "mcp2515.h"
#include "can.h"
#include "pwm.h"
#include "adc.h"
#include "motor.h"
#include "solenoid.h"
#include "ir_sensor.h"
#include "TWI_Master.h"
#include "timer.h"
#include "pid.h"
#include "game.h"
#include "dac.h"



int main( void )
{
	uart_init ( MYUBRR );					//init
	can_init();
	adc_init();
	solenoid_init();
	pwm_init();
	init_dac();
	control_init();
	
	pi_init();								//init timer intererupt
	can_interrupt_init();					//init can interrupt


	printf("Welcome\n");
	
	CAN_message_t start;
	
	while(1)
	{
		int ir = adc_read(IR_Sensor);
		printf("%d\n",ir);
		
		start = can_data_receive();
		if(start.id == 90)
		{
			enable_solenoid();						//shoot out ball to start playing
			pi_update_max_speed(start.data[0]);		//set difficulty
			play_game();							//play game
		}	
	}

}




