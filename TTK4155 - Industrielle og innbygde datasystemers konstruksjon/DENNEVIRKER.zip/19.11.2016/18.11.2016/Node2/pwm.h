/*
 * pwm.h
 *
 * Created: 31.10.2016 18:53:06
 *  Author: jumaili
 */ 


#ifndef PWM_H_
#define PWM_H_
#define FCPU 16000000UL
void pwm_init();
void pwm_width(float poswidth_ms);
void servo_control(int xpos);



#endif /* PWM_H_ */