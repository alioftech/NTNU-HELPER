/*
 * game.h
 *
 * Created: 17.11.2016 18:42:12
 *  Author: erlenhaa
 */ 


#ifndef GAME_H_
#define GAME_H_

void play_game(void);

#endif /* GAME_H_ */