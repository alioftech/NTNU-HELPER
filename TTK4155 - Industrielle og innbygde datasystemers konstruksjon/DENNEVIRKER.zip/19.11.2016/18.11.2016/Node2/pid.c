/*
* pid.c
*
* Created: 17.11.2016 18:29:53
*  Author: erlenhaa
*/
#include "pid.h"
#include "motor.h"
#include "setup.h"
#include "uart.h"

#include <avr/io.h>
#include <stdint-gcc.h>
#include <avr/interrupt.h>
#include <stdio.h>

int16_t pos_ref;
int16_t difficulty;
int16_t middle;
int16_t error;
int16_t measured;
float integral;
float dt;
int16_t speed;
int16_t max_speed;

float Kp;
float Ki;

int counter;

void pi_timer_init()
{
	cli();																			//init pi compare timer with sampling time 0.02s
	OCR1A = 5000;
	TCCR1A |= (1<<COM1A0);
	TCCR1B |= (1 << CS11) | (1<<CS10) | (1<< WGM12);
	TIMSK1 |= (1<< OCIE1A);
	sei();
}


void pi_init()
{
	pos_ref = 0;
	measured = 0;
	integral = 0;
	error = 0;
	speed = 0;
	difficulty = 0;																	//easy diff
	max_speed = 150;
	
	dt = 0.02;																		//Set sampling time
	
	Kp = 4;																			//set gain
	Ki = 1;																			//set integral gain
	counter =0;
	//TODO: move into  timer function *************
	pi_timer_init();

}

void pi_update_pos(int16_t pos)														//update and invert reference posion to fit encoder counter
{
	pos_ref = -pos +100;
}
void pi_update_max_speed(int diff)												//update and invert reference posion to fit encoder counter
{
	if (diff == 0)
	{
		max_speed = 150;
	}
	else if (diff == 1)
	{
		max_speed = 100;
	}
	else if (diff == 2)
	{
		max_speed = 75;
	}
																			
}


void pi_controller()
{
	if (counter >0)
	{
		int16_t read = read_encoder();												//read encoder value
		measured = read*100.0/encoder_MAX;											//format encoder measurement
		
		error = pos_ref - measured;													//calculate error;
		
		integral = integral + error*dt*counter;												//update integral
		
		
		if (error < 1 && error > -1)												//reset integral when error is gone
		{
			integral = 0;
		}

		int16_t speed_sign = Kp*error + Ki*integral;								//calculate speed with sign +-
		
		if (speed_sign > 0)															//direction = RIGHT 
		{
					speed = speed_sign;		
					motor_direction('l');
		}
		else																		//direction	= LEFT, remove sign from speed
		{
			speed = -speed_sign;
			motor_direction('r');
		}

		
		if (speed > max_speed)															//restrain Power to 150
		{
			speed = max_speed;
		}
		
		motor_speed(speed);															//set motor speed
		counter = 0;															//reset pi counter
	}
	
	else{}
	//Ignore
	
}


ISR(TIMER1_COMPA_vect)
{
	counter ++;
}

