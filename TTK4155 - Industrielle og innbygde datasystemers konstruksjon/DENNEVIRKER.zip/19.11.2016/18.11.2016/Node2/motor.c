
/*
* motor.c
*
* Created: 06.11.2016 13:32:56
*  Author: erlenhaa
*/

#include <avr/io.h>
#include <util/delay.h> //include delays
#include <avr/interrupt.h>
#include <stdio.h>
#include "motor.h"
#include "TWI_Master.h"
#include "uart.h"
#include "setup.h"

#define OE	PH5// 5			//number 5 [the 3rd on MJ1 cable]
#define RST PH6//6			//number 6 [the 4th on MJ1 cable]
#define SEL PH3 //3			//number 3 [5th on MJ1 cable]
#define EN  PH4//4			//number 4 [the 6th on MJ1 cable]
#define DIR PH1//1			//number 1 [the 7th on MJ1 cable]

#define MJ1_PORT PORTH
#define MJ1_DDR DDRH

#define MJ2_PORT PORTK
#define MJ2_DDR DDRK
#define MJ2_DATA PINK

#define Kp 1
#define Ki 1



void control_init(void)
{
	
	MJ1_DDR |= (1<< OE)| (1<< RST)| (1<< SEL)| (1<< EN)| (1<< DIR);//MJ1 OUTPUT connected to port Atmega256
	MJ2_DDR=0x00;													//MJ2 INPUT connected to port K on Atmega2560, MJ2 on expansion card
	
	MJ1_PORT |=(1<<EN);												//enable motor
	
	//drive motor to the far right
	encoder_reset();
	motor_direction('r');
	motor_speed(90);
	int16_t max_val=0, prev_max_value=-1;
	while (max_val!=prev_max_value){
		_delay_ms(150);
		max_val=read_encoder();
		_delay_ms(150);
		prev_max_value=read_encoder();
		
	}
	_delay_ms(30);
	motor_direction('r');
	motor_speed(0);
	
	encoder_reset();

	//drive motor to the far left and set maxvalue
	motor_direction('l');
	motor_speed(90);
	max_val=0, prev_max_value=-1;
	while (max_val!=prev_max_value){
		_delay_ms(150);
		max_val=read_encoder();
		_delay_ms(150);
		prev_max_value=read_encoder();
		
	}
	
	motor_speed(0);
	_delay_ms(150);
	motor_direction('r');
	motor_speed(90);
	//drive motor to the middle
	int16_t center = max_val/2;
	while(1){
		int16_t value = read_encoder();
		if (value <center){
			break;
		}
	}
	motor_speed(0);
	
	encoder_MAX=max_val;
	printf("max encoder motor =%d \n",max_val);
	
}

void motor_speed(uint8_t speed)
{

	uint8_t msg[3] = {0x5E, 0x00, speed};				//Send motor speed send /addresse, command and data
	TWI_Start_Transceiver_With_Data(msg, 3);			//send the msg
}

void motor_direction(char dir)
{
		if (dir == 'r')
		{
			set_bit(MJ1_PORT, DIR);				//Select direction
			_delay_us(20);
		}
		else if (dir == 'l')
		{
			clear_bit(MJ1_PORT, DIR);
			_delay_us(20);
		}
}

void encoder_reset()
{
	clear_bit(MJ1_PORT,RST);	//Toggle !RST
	_delay_ms(20);
	set_bit(MJ1_PORT,RST);
	
}

int16_t read_encoder(void)
{
	uint8_t msb = 0;
	uint8_t lsb = 0;
	clear_bit(MJ1_PORT, OE);	//set OE low to enable output of encoder
	clear_bit(MJ1_PORT, SEL);	//set SEL low to get high byte
	_delay_us(20);			//wait 20us
	
	msb = MJ2_DATA;	//read  MSB
	set_bit(MJ1_PORT, SEL);		//set SEL high to get low byte
	_delay_us(20);
	lsb = MJ2_DATA;	// read LSB
	set_bit(MJ1_PORT, OE);	//Set OE high to diable output encoder
	
	int16_t encoder_value = (((int16_t)msb << 8) | (int16_t)lsb);

	
	return encoder_value;
}
