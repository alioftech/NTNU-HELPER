/*
 * adc.h
 *
 * Created: 02.11.2016 13:50:16
 *  Author: erlenhaa
 */ 


#ifndef ADC_H_
#define ADC_H_

#include <stdint-gcc.h>


void adc_init(void);
uint16_t adc_read(int);



#endif /* ADC_H_ */