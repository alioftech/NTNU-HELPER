/*
 * motor.h
 *
 * Created: 06.11.2016 13:33:05
 *  Author: erlenhaa
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_

#include <stdint-gcc.h>

typedef enum {LEFT, RIGHT} dir_t;
	
int16_t encoder_MAX;			//global

void control_init(void);
void motor_speed(uint8_t speed);
void motor_direction(char dir);
int16_t read_encoder(void);
void encoder_reset(void);



//void max520_init(uint8_t max520_twi_addr);
//void max520_write(char ch, char val);

//#include <stdint.h>
//
//typedef enum MotorDirection MotorDirection;
//enum MotorDirection {
	//right,
	//left
//};
//
//void motor_init(void);
//void motor_enable(void);
//void motor_twiAddr(uint8_t addr);
//void motor_speed(uint8_t speed);
//void motor_direction(MotorDirection dir);
//void motor_velocity(float vel);
//int16_t motor_encoderRead(void);
//void motor_encoderReset(void);

#endif /* MOTOR_H_ */