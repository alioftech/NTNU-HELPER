/*
 * solenoid.c
 *
 * Created: 06.11.2016 16:23:45
 *  Author: erlenhaa
 */ 
#include "setup.h"
#include "solenoid.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define SOLENOID_PIN PD3


void solenoid_init()
{
	DDRD |= (1<<SOLENOID_PIN); // set port to output
	PORTD |= (1<<SOLENOID_PIN); //enable pullup
	set_bit(PORTD,PD3);
	_delay_ms(20);
}

void enable_solenoid(void)
{
		//cli();
		clear_bit(PORTD,PD3);
		_delay_ms(50);
		set_bit(PORTD,PD3);
		_delay_ms(10);
		//sei();
}