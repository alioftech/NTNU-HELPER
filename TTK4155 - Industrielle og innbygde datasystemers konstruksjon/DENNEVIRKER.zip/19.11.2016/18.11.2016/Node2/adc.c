/*
 * adc.c
 *
 * Created: 02.11.2016 13:49:49
 *  Author: erlenhaa
 */ 

#include "adc.h"
#include <avr/io.h>
#include <stdint-gcc.h>

void adc_init(void)
{
	    ADCSRA  |=  (1<<ADEN);	//ADC Enable
		ADCSRA  |=	(1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0); // Clock prescaler to 128
		ADMUX = (1 << REFS0); //Selecting AVCC as reference
}

uint16_t adc_read(int ch){

	ADMUX =  (ch & 0x1f);	//Selecting ADC channel
	ADCSRA |= (1<<ADSC);	//start conversion
	
	while( (ADCSRA & (1<<ADSC)) ); //Wait for conversion to be done.
	
	return ADC;  //return the ADC conversion result from the ADC Result Registers (ADCL, ADCH)
}

