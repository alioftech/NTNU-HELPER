/*
 * ir_sensor.h
 *
 * Created: 06.11.2016 15:22:39
 *  Author: erlenhaa
 */ 


#ifndef IR_SENSOR_H_
#define IR_SENSOR_H_

#include <stdint.h>

#define IR_Sensor 0


uint8_t ir_obstructed(void);



#endif /* IR_SENSOR_H_ */