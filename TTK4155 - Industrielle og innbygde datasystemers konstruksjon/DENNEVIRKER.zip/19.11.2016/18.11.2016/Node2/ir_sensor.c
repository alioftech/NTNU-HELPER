/*
 * ir_sensor.c
 *
 * Created: 06.11.2016 15:22:25
 *  Author: erlenhaa
 */ 

#include <stdio.h>

#include "ir_sensor.h"
#include "adc.h"
#include "uart.h"

#define THRESHOLD 70

int sampling_var = 0;

uint8_t ir_obstructed()
{	
	if (adc_read(IR_Sensor) < THRESHOLD)					//add to the sampling variable when ir value is less than threshold
	{
		sampling_var++;
		
	}
	else if (adc_read(IR_Sensor) >= THRESHOLD)				//reset sampling variable if ir value is back over threshold value
	{
		sampling_var = 0;
	}
	
	if (sampling_var == 3)									//return 1 when sampling value reaches 3
	{
		sampling_var = 0;
		return 1;
	}
	else
		return 0;											//return 0 if sampling value is not reached
}