/*
 * solenoid.h
 *
 * Created: 06.11.2016 16:23:26
 *  Author: erlenhaa
 */ 


#ifndef SOLENOID_H_
#define SOLENOID_H_

void solenoid_init(void);
void enable_solenoid(void);



#endif /* SOLENOID_H_ */