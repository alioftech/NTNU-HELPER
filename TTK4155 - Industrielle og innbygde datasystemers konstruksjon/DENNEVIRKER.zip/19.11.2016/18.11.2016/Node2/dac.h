/*
 * dac.h
 *
 * Created: 17.11.2016 21:36:59
 *  Author: erlenhaa
 */ 


#ifndef DAC_H_
#define DAC_H_


void init_dac(void);


#endif /* DAC_H_ */