/*
 * timer.h
 *
 * Created: 13.11.2016 19:04:45
 *  Author: erlenhaa
 */ 


#ifndef TIMER_H_
#define TIMER_H_

typedef struct Timer Timer;
struct Timer {
	volatile uint16_t*  source;
	uint16_t            prescaler;
};



#endif /* TIMER_H_ */