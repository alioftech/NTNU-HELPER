/*
* can.c
*
* Created: 12.10.2016 14:55:44
*  Author: erlenhaa
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "setup.h"
#include "mcp2515.h"
#include "can.h"

uint8_t can_interupt_flag = 0;

void can_init(void) {
	
	mcp2515_init();													//set config mode
	mcp2515_bit_modify(MCP_RXB0CTRL, 0b01100100, 0xFF);				//RX0 disable rollover
	mcp2515_bit_modify(MCP_CANINTE, 0x01, 1);						//Enable interrupt when message is received 
	mcp2515_bit_modify(MCP_CANCTRL, MODE_MASK, MODE_NORMAL);		//set normal mode
}

int can_message_send(CAN_message_t* message) {
	uint8_t i;
	
	
	if (can_transmit_complete())									//Check if there is no pending transmission
	{
		mcp2515_write(MCP_TXB0SIDH, (int8_t)(message->id >> 3));	//Set the message id (use standard identifier)
		mcp2515_write(MCP_TXB0SIDL, (int8_t)(message->id << 5));	//Set the message id (use standard identifier)
		
		mcp2515_write(MCP_TXB0DLC, (0x0F) & (message->length));		//Set data length and use data frame (RTR = 0)

		for (i = 0; i < message->length; i++)
		{
			mcp2515_write(MCP_TXB0D0 + i, message->data[i]);		//Set data bytes (max. 8 bytes)
			
		}
		
		mcp2515_request_to_send(1);									//Request to send via TX0
		
	}
	else
	{
		if (can_error() < 0) {
			return -1;
		}
	}
	return 0;
}


int can_error(void) {
	uint8_t error = mcp2515_read(MCP_TXB0CTRL);
	

	if (test_bit(error, 4)) return -1;								//Transmission error detected
	if (test_bit(error, 5)) return -2;								//Message lost arbitration
	
	return 0;
}


int can_transmit_complete(void) {
	
	if (test_bit(mcp2515_read(MCP_TXB0CTRL), 3))															//Check if TX buffer is not pending transmission (TXREQ = 0)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}


CAN_message_t can_data_receive(void) {
	uint8_t i;
	CAN_message_t message;
	
	
	if (can_interupt_flag == 1)																				//Check if RX buffer has a message
	{
		message.id  = (mcp2515_read(MCP_RXB0SIDH) << 3) | (mcp2515_read(MCP_RXB0SIDL) >> 5);				//Get message id
		message.length = (0x0F) & (mcp2515_read(MCP_RXB0DLC));												//Get message length
		
		for(i = 0; i < message.length; i++)																	//Get message data
		{
			message.data[i] = mcp2515_read(MCP_RXB0D0 + i);
		}
		
		can_interupt_flag = 0;																				//Clear interrupt flag
		mcp2515_bit_modify(MCP_CANINTF, 0x01, 0);															//clear interupt register
		
	}
	else
	{
		
		message.id = -1;																					//Message was not received
	}
	
	return message;
}


void can_interrupt_init()
{
	cli();																								
	DDRE &= ~(1<<PINE4);																					//input PE4
	PORTE |= (1<<PE4);																						//enable pululp
	EICRB |= (1<<ISC41);																					//Trigger on falling edge
	EICRB &= ~(1<<ISC40);																					//Trigger on falling edge
	EIMSK |= (1<<INT4);																						//Enable INT4

	sei();																									//enable global interupt
}

ISR(INT4_vect) 
{
	can_interupt_flag = 1;																					//set interupt flag
}