/*
 * DAC.c
 *
 * Created: 17.11.2016 21:36:16
 *  Author: erlenhaa
 */ 

#include <avr/interrupt.h>
#include "TWI_Master.h"
void init_dac(void)
{
	
	TWI_Master_Initialise();
	sei();
	
}