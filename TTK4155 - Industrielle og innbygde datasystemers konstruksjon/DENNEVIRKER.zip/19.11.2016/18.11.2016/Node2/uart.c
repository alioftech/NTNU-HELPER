/*
* UART.c
*
* Created: 07.09.2016 09:06:26
*  Author: amundho
*/



#include <avr/io.h> //for registers
#include <stdio.h>
#include "uart.h"
#define NULL 0

static FILE uart_stdio = FDEV_SETUP_STREAM(&uart_transmit, &uart_receive, _FDEV_SETUP_RW);

unsigned int uart_transmit(unsigned char data)
{
	loop_until_bit_is_set(UCSR0A,UDRE0);//wait by checking the flag until transmitter buffer is empty
	UDR0 = data;//puts data into buffer and sends it
	return 0; //transmitt ok
}

unsigned int uart_receive(void)
{
	loop_until_bit_is_set(UCSR0A,UDRE0);//wait by checking the flag until transmitter buffer is empty
	return UDR0;
}

void uart_init( unsigned int ubrr )
{
	//Set baud rate
	UBRR0H = (unsigned char)	(ubrr>>8);
	UBRR0L = 	(unsigned char) ubrr ;
	
	UCSR0B=(1<<RXEN0)|(1<<TXEN0); 	//Enable(set) the receiver and transmitter
	
	
	UCSR0C &= ~(1 << UMSEL00); // Choose UART not USART (clears the bit)
	UCSR0C &= ~(1 << UMSEL01); // Choose UART not USART (clears the bit)
	UCSR0C = (1<<USBS0)| (1<<UCSZ00) |(1<<UCSZ01); //Set frame format: 8data, 2stop bit
	//MCUCR &= ~(1 << JTD);
	
		stdout =&uart_stdio; //connect printf to uart_Transmit
		stdin  =&uart_stdio; //connect printf to uart_recieve
	
}