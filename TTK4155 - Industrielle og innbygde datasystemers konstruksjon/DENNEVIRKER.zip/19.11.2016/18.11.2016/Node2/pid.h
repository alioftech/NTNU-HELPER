/*
 * pid.h
 *
 * Created: 17.11.2016 18:30:16
 *  Author: erlenhaa
 */ 


#ifndef PID.H_H_
#define PID.H_H_

void pi_timer_init(void);
void pi_init(void);
void pi_update_pos(int16_t);
void pi_update_max_speed(int);		
void pi_controller(void);


#endif /* PID.H_H_ */