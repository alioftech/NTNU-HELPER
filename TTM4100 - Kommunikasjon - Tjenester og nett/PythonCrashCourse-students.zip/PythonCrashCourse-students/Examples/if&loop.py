mark = 85

if mark >= 90:
    print 'You got an A'
    print 'Congrats!'
elif 80 <= mark <= 90:
    print 'You got a B'
else:
    print "You didn't get an A or a B"



i=0
while i<=10:
    print i
    i += 1


for i in range(11):
    print i
