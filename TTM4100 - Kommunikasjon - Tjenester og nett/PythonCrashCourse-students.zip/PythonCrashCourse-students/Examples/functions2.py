def convCelToFah (c):
    return c * 9.0 / 5.0 +32

def main():         #A function without arguments
    #Celsius to Fahrenheit converter

    c = input("Temperature in Celsius to convert: ")
    f = convCelToFah(c)
    print "{} Celsius are {} in Fahrenheit".format(c,f)

main()      #This is the first line of code actually executed and just calls function main!!!
