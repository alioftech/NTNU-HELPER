try:
    f = open("input.txt") 
except IOError:
    print "That file does not exist!"
else:
    pass
    #Do something with the file
