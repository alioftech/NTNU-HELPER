print 'abc' * 2     #This Works!!!
print 'abc'+'def'


print 'a' in 'abc'          # -> True
print 'z' in 'abc'          # -> False
print 'za' in 'zasca'       # -> True
print 'za' in 'zosca'       # -> False

a = None
print a is None             # -> True


