person1 = {'name':'robin hood', 'age':53, 'weight':75}

print person1['name']
print person1['age']
print person1['weight']

person1['hair'] = 'black'
print person1

person1['name'] = 'john connor'
print person1

for d in person1:
    print d
for d in person1.values():
    print d
