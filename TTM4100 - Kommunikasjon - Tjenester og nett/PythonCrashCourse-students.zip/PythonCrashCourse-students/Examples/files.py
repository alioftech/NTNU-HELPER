f = open("h.txt")

buffer = f.read()

print buffer

f.close

f = open("h.txt")
line = f.readline()
while line:
    print line
    line = f.readline()
    
f.close
