a = 2
print a
print a/2

a = 'HI'
print a

print int('2')      #Convert string to integer
print str(1+1)      #convert integer to string
print eval("3+9")   #Do math with strings

first, second = 2, 'HI'
first, second = second, first
print first
print second

print int('2')/2    #Works
#print str(1+1)/2   #Error!!

