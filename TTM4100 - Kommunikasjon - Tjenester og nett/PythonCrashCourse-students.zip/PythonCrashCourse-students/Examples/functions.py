def square(x):
    return x*x

print square(3)

def cube(x):
    return x*square(x)

print cube(3)
