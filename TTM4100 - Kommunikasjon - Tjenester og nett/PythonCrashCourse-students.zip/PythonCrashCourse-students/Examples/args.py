import sys

argv = sys.argv
x = argv[0]
y = argv[1]
z = argv[2]

print x
print y
print z
