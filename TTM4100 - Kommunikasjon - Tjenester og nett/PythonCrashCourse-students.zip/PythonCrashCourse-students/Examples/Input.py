x = raw_input("Give me a string:")
print x+'!!!'

x = input("Give me a number:")
print x+2

print "Your number is:", x
print "Your number is: {} and its square is {}".format(x, x*x)

