class BankAccount():
    #A class that simulates a Bank Account
    def __init__ (self, initBalance):            #Constuctor
        #Set the balance to zero
        self.balance = initBalance
    def deposit (self, amount):
        #Deposit money
        self.balance = self.balance + amount
    def withdraw (self, amount):
        #Withdraw money
        self.balance = self.balance - amount
    def getBalance (self):
        #Check the balance
        return self.balance


myAccount = BankAccount(0)      # Create object myAccount is an object!!! This calls the Constructor
print myAccount.getBalance()    # Call method getBalance from myAccount
myAccount.deposit(200)          # Call method deposit from myAccount
print myAccount.getBalance()
myAccount.withdraw(50)          # Call method withdraw 
print myAccount.getBalance()

mySecondAccount = BankAccount(50)   #Create a second object, with the same methods and variables!
mySecondAccount.withdraw(10)        # Call method withdraw 
print mySecondAccount.getBalance()

class InterestBA(BankAccount):
    def __init__ (self, initBalance):            #Constuctor
        #Set the balance to zero
        BankAccount.__init__(self, initBalance)
        self.interest = 0.2
    def finalInterest(self):
        return self.balance + self.balance*self.interest

myInterestAccount = InterestBA(50)
myInterestAccount.deposit(50)
print myInterestAccount.finalInterest()
