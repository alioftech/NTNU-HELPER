for i in range(11):
    print i
    if i == 9:
        break
    elif i <= 2:
        continue
    else:
        print "i is bigger than 2 and we haven't reached 9"


print "Out of the loop, i is 9"

if a<b and x<=3:
    pass
else:
    #Do something here
    #This will give an error


