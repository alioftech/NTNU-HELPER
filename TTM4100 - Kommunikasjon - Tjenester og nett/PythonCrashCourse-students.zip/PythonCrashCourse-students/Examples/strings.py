print 'Hi'
print "Hi"
print "Hi"
print '"Hi"'
print "'Hi'"
print '''How
are
you'''

print 'one\ntwo\tthree'

w = 'Hello, world!'
print w[0]
print w[2:4]
print w[:5]
print w[7:]

w[0] = 'r'          # Error!!!

