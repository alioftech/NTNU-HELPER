x = 4
def scopeTest(a):
    x = 7
    print x             #Prints 7
    return x+a

print scopeTest(3)      #Prints 10
print x                 #Prints 4


def change(some_list):
    some_list[1] = 4

x = [1,2,3]
change(x)
print x                 #Prints [1,4,3]

def nochange(x):
    x = 0

y = 1
nochange(y)
print y                 #Prints 1
