lst = [1, 4, 7]
lst2 = [1, 2.4, 'qbc']

print lst
print lst2
lst[1] = 0
print lst

lst3 = ['michael','john',lst]
print lst3
print lst3[1]
print lst3[2]
print lst3[2][2]

a = [0,1,2]
b = a #copy the reference
b[0] = 7
print a

a = [0,1,2]
b = a[:] #copy values
b[0] = 7
print a
print b

w = 'How are you doing?'
wlist = w.split()
for i in wlist:
    print i
wlist[0] = 'he'
for i in wlist:
    print i
